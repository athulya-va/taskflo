STUDENT TASK MANAGER — BEGINNER-FRIENDLY MERN PROJECT
=====================================================

WHAT IS THIS PROJECT?
This is a simple Student Task Manager built with the MERN stack:
- MongoDB: stores your tasks
- Express.js: provides the backend API
- React: displays the website
- Node.js: runs the backend server

FEATURES
- Add a task with title, description, due date and priority
- View all saved tasks
- Mark tasks as completed or pending
- Edit a task
- Delete a task
- Filter tasks by status
- Responsive layout for desktop and mobile

PROJECT FOLDERS
student-task-manager-mern/
  client/     React frontend
  server/     Express backend
  .gitignore
  README.txt

BEFORE YOU START
Install these tools:
1. Node.js (LTS): https://nodejs.org/
2. Git: https://git-scm.com/downloads
3. A code editor such as Visual Studio Code
4. A MongoDB database. Beginner option: create a free MongoDB Atlas cluster:
   https://www.mongodb.com/atlas

STEP 1 — OPEN THE PROJECT
1. Extract the ZIP file.
2. Open Visual Studio Code.
3. Choose File > Open Folder.
4. Select the extracted student-task-manager-mern folder.

STEP 2 — SET UP THE DATABASE
Option A: MongoDB Atlas
1. Create a MongoDB Atlas account and a cluster.
2. Create a database user with a password.
3. In Network Access, allow your current IP address for development.
4. Choose Connect > Drivers and copy the connection string.
5. Replace <username>, <password>, and the database name in that string.
   Do not share your real connection string publicly.

Option B: Local MongoDB
If MongoDB is installed and running locally, you can use:
mongodb://127.0.0.1:27017/student_task_manager

STEP 3 — CONFIGURE THE BACKEND
1. Open a terminal in VS Code (Terminal > New Terminal).
2. Run:
   cd server
   npm install
3. Copy .env.example to a new file named .env.
   On Windows PowerShell, you can run:
   Copy-Item .env.example .env
4. Open server/.env and set MONGODB_URI to your database connection string.
   Example:
   PORT=5000
   MONGODB_URI=mongodb://127.0.0.1:27017/student_task_manager
   CLIENT_URL=http://localhost:5173
5. Start the backend:
   npm run dev
6. Keep this terminal open. The API runs at http://localhost:5000.
   Visit http://localhost:5000/api/health to check the server.

STEP 4 — CONFIGURE THE FRONTEND
1. Open a SECOND terminal in VS Code.
2. Run:
   cd client
   npm install
3. Copy client/.env.example to client/.env:
   Copy-Item .env.example .env
4. Start React:
   npm run dev
5. Open the local address shown in the terminal, usually:
   http://localhost:5173

IMPORTANT: Keep both terminals running while you use the site.

HOW TO USE THE WEBSITE
1. Type a task title.
2. Optionally add a description, due date and priority.
3. Click Add Task.
4. Use the status buttons to mark a task completed or pending.
5. Click Edit to update a task.
6. Click Delete to remove a task.
7. Use the filter buttons to view all, pending or completed tasks.

COMMON FIXES
- "npm is not recognized": install Node.js, then close and reopen VS Code.
- Database connection error: check MONGODB_URI, database username/password and Atlas network access.
- Website loads but tasks do not: confirm the backend terminal is running and client/.env uses
  VITE_API_URL=http://localhost:5000/api.
- Port already in use: close the other process or change PORT in server/.env.
- Never upload .env files or passwords to GitHub.

PUSH THE PROJECT TO GITHUB
1. Sign in to https://github.com/ and create a NEW repository.
2. Give it a name such as student-task-manager-mern.
3. Do not add a README or .gitignore on GitHub if you already have these files locally.
4. In VS Code, open a terminal at the project root (the folder containing client and server).
5. Run these commands one by one:

   git init
   git add .
   git status
   git commit -m "Create Student Task Manager MERN project"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/student-task-manager-mern.git
   git push -u origin main

Replace YOUR-USERNAME with your GitHub username and use the repository URL GitHub gives you.
If Git asks you to sign in, follow the browser sign-in prompt.
Before pushing, check that .env and node_modules are not listed by git status.

YOUR GITHUB REPOSITORY LINK
After the push succeeds, your link will look like:
https://github.com/YOUR-USERNAME/student-task-manager-mern

TEST CHECKLIST
[ ] Add a task
[ ] Refresh the page and check the task remains
[ ] Edit a task
[ ] Mark a task complete and pending
[ ] Filter tasks
[ ] Delete a task
[ ] Check the app on a narrow/mobile screen
[ ] Check that no .env file is in GitHub

NOTES
- This starter project does not include user accounts or login.
- Anyone who can access your deployed app may be able to see the tasks in its database.
  Use sample/demo data only until authentication and access controls are added.
- This ZIP is a starter project. Run and test it locally before submitting it.
