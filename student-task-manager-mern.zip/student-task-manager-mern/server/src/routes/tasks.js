import express from "express";
import mongoose from "mongoose";
import Task from "../models/Task.js";

const router = express.Router();

function validId(id) {
  return mongoose.isValidObjectId(id);
}

router.get("/", async (req, res, next) => {
  try {
    const tasks = await Task.find().sort({ completed: 1, createdAt: -1 });
    res.json(tasks);
  } catch (error) {
    next(error);
  }
});

router.post("/", async (req, res, next) => {
  try {
    const { title, description = "", dueDate = null, priority = "Medium" } = req.body;
    if (typeof title !== "string" || !title.trim()) {
      return res.status(400).json({ message: "Please provide a task title." });
    }
    const task = await Task.create({ title, description, dueDate: dueDate || null, priority });
    res.status(201).json(task);
  } catch (error) {
    next(error);
  }
});

router.put("/:id", async (req, res, next) => {
  try {
    if (!validId(req.params.id)) return res.status(400).json({ message: "Invalid task ID." });
    const { title, description, dueDate, priority } = req.body;
    if (typeof title !== "string" || !title.trim()) {
      return res.status(400).json({ message: "Please provide a task title." });
    }
    const task = await Task.findByIdAndUpdate(
      req.params.id,
      { title: title.trim(), description, dueDate: dueDate || null, priority },
      { new: true, runValidators: true }
    );
    if (!task) return res.status(404).json({ message: "Task not found." });
    res.json(task);
  } catch (error) {
    next(error);
  }
});

router.patch("/:id", async (req, res, next) => {
  try {
    if (!validId(req.params.id)) return res.status(400).json({ message: "Invalid task ID." });
    if (typeof req.body.completed !== "boolean") {
      return res.status(400).json({ message: "Completed must be true or false." });
    }
    const task = await Task.findByIdAndUpdate(
      req.params.id,
      { completed: req.body.completed },
      { new: true, runValidators: true }
    );
    if (!task) return res.status(404).json({ message: "Task not found." });
    res.json(task);
  } catch (error) {
    next(error);
  }
});

router.delete("/:id", async (req, res, next) => {
  try {
    if (!validId(req.params.id)) return res.status(400).json({ message: "Invalid task ID." });
    const task = await Task.findByIdAndDelete(req.params.id);
    if (!task) return res.status(404).json({ message: "Task not found." });
    res.json({ message: "Task deleted successfully." });
  } catch (error) {
    next(error);
  }
});

export default router;
