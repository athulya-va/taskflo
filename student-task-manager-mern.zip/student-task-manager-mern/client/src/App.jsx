import { useEffect, useMemo, useState } from "react";

const API_URL = (import.meta.env.VITE_API_URL || "http://localhost:5000/api").replace(/\/$/, "");
const emptyForm = { title: "", description: "", dueDate: "", priority: "Medium" };

function readableDate(value) {
  if (!value) return "No due date";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "No due date" : date.toLocaleDateString();
}

export default function App() {
  const [tasks, setTasks] = useState([]);
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState(null);
  const [filter, setFilter] = useState("All");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  async function loadTasks() {
    setLoading(true);
    setError("");
    try {
      const response = await fetch(`${API_URL}/tasks`);
      const data = await response.json();
      if (!response.ok) throw new Error(data.message || "Could not load tasks.");
      setTasks(data);
    } catch (err) {
      setError(`${err.message} Check that the backend and MongoDB are running.`);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadTasks(); }, []);

  const visibleTasks = useMemo(() => {
    if (filter === "Pending") return tasks.filter((task) => !task.completed);
    if (filter === "Completed") return tasks.filter((task) => task.completed);
    return tasks;
  }, [tasks, filter]);

  const completedCount = tasks.filter((task) => task.completed).length;

  function changeForm(event) {
    setForm({ ...form, [event.target.name]: event.target.value });
  }

  async function submitTask(event) {
    event.preventDefault();
    if (!form.title.trim()) {
      setError("Please enter a task title.");
      return;
    }
    setSaving(true);
    setError("");
    setNotice("");
    const payload = { ...form, title: form.title.trim() };
    try {
      const response = await fetch(
        editingId ? `${API_URL}/tasks/${editingId}` : `${API_URL}/tasks`,
        {
          method: editingId ? "PUT" : "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        }
      );
      const data = await response.json();
      if (!response.ok) throw new Error(data.message || "Could not save the task.");
      setForm(emptyForm);
      setEditingId(null);
      setNotice(editingId ? "Task updated successfully." : "Task added successfully.");
      await loadTasks();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  function startEdit(task) {
    setEditingId(task._id);
    setForm({
      title: task.title || "",
      description: task.description || "",
      dueDate: task.dueDate ? task.dueDate.slice(0, 10) : "",
      priority: task.priority || "Medium",
    });
    setNotice("");
    setError("");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function cancelEdit() {
    setEditingId(null);
    setForm(emptyForm);
    setError("");
  }

  async function toggleCompleted(task) {
    setError("");
    try {
      const response = await fetch(`${API_URL}/tasks/${task._id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ completed: !task.completed }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.message || "Could not update task.");
      await loadTasks();
    } catch (err) {
      setError(err.message);
    }
  }

  async function deleteTask(task) {
    if (!window.confirm(`Delete "${task.title}"?`)) return;
    setError("");
    try {
      const response = await fetch(`${API_URL}/tasks/${task._id}`, { method: "DELETE" });
      const data = await response.json();
      if (!response.ok) throw new Error(data.message || "Could not delete task.");
      setTasks((current) => current.filter((item) => item._id !== task._id));
      setNotice("Task deleted.");
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <main className="page">
      <header className="hero">
        <div className="hero-copy">
          <span className="eyebrow">STUDENT PRODUCTIVITY</span>
          <h1>Make room for what matters.</h1>
          <p>One simple place for your assignments, projects and study goals.</p>
        </div>
        <div className="hero-icon" aria-hidden="true">✓</div>
      </header>

      <section className="stats" aria-label="Task summary">
        <article className="stat-card"><span>Total tasks</span><strong>{tasks.length}</strong></article>
        <article className="stat-card"><span>Pending</span><strong>{tasks.length - completedCount}</strong></article>
        <article className="stat-card"><span>Completed</span><strong>{completedCount}</strong></article>
      </section>

      <section className="content-grid">
        <section className="panel form-panel">
          <div className="section-heading">
            <div><span className="eyebrow">{editingId ? "UPDATE DETAILS" : "GET STARTED"}</span>
              <h2>{editingId ? "Edit your task" : "Add a new task"}</h2></div>
          </div>
          <form onSubmit={submitTask}>
            <label htmlFor="title">Task title *</label>
            <input id="title" name="title" value={form.title} onChange={changeForm}
              placeholder="e.g. Finish Java assignment" maxLength="120" required />
            <label htmlFor="description">Description</label>
            <textarea id="description" name="description" value={form.description}
              onChange={changeForm} placeholder="Add a few details..." rows="3" maxLength="1000" />
            <div className="form-row">
              <div><label htmlFor="dueDate">Due date</label>
                <input id="dueDate" name="dueDate" type="date" value={form.dueDate} onChange={changeForm} /></div>
              <div><label htmlFor="priority">Priority</label>
                <select id="priority" name="priority" value={form.priority} onChange={changeForm}>
                  <option>Low</option><option>Medium</option><option>High</option>
                </select></div>
            </div>
            <button className="primary-button" type="submit" disabled={saving}>
              {saving ? "Saving..." : editingId ? "Save changes" : "+ Add task"}
            </button>
            {editingId && <button className="secondary-button full-width" type="button" onClick={cancelEdit}>Cancel editing</button>}
          </form>
        </section>

        <section className="panel tasks-panel">
          <div className="tasks-title">
            <div><span className="eyebrow">YOUR WORKSPACE</span><h2>My tasks</h2></div>
            <button className="refresh-button" onClick={loadTasks} type="button" aria-label="Refresh tasks">↻</button>
          </div>
          <div className="filters" aria-label="Filter tasks">
            {["All", "Pending", "Completed"].map((item) =>
              <button key={item} type="button" className={filter === item ? "filter active" : "filter"}
                onClick={() => setFilter(item)}>{item}</button>
            )}
          </div>

          {error && <div className="message error" role="alert">{error}</div>}
          {notice && !error && <div className="message success" role="status">{notice}</div>}

          {loading ? <div className="empty-state"><div className="loader" /><p>Loading your tasks...</p></div>
            : visibleTasks.length === 0 ? (
              <div className="empty-state"><div className="empty-icon">✦</div>
                <h3>{filter === "All" ? "A fresh start!" : `No ${filter.toLowerCase()} tasks`}</h3>
                <p>{filter === "All" ? "Add your first task using the form." : "Try another filter or add a new task."}</p>
              </div>
            ) : <div className="task-list">
              {visibleTasks.map((task) => (
                <article className={`task-card ${task.completed ? "is-complete" : ""}`} key={task._id}>
                  <button className={`check-button ${task.completed ? "checked" : ""}`}
                    onClick={() => toggleCompleted(task)} type="button"
                    aria-label={task.completed ? "Mark pending" : "Mark completed"}>
                    {task.completed ? "✓" : ""}
                  </button>
                  <div className="task-details">
                    <div className="task-name-row"><h3>{task.title}</h3>
                      <span className={`priority priority-${(task.priority || "Medium").toLowerCase()}`}>{task.priority || "Medium"}</span></div>
                    {task.description && <p className="description">{task.description}</p>}
                    <div className="task-meta"><span>◷ {readableDate(task.dueDate)}</span>
                      <span>{task.completed ? "Completed" : "Pending"}</span></div>
                    <div className="task-actions">
                      <button type="button" onClick={() => startEdit(task)}>Edit</button>
                      <button type="button" className="delete-action" onClick={() => deleteTask(task)}>Delete</button>
                    </div>
                  </div>
                </article>
              ))}
            </div>}
        </section>
      </section>
      <footer>Built with React, Express, Node.js and MongoDB · Student Task Manager</footer>
    </main>
  );
}
